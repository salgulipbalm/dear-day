import { getStore } from "@netlify/blobs";
import { randomUUID, timingSafeEqual } from "node:crypto";

const store = getStore("dear-day");
const headers = {
  "content-type": "application/json; charset=utf-8",
  "cache-control": "no-store",
  "access-control-allow-origin": "*",
  "access-control-allow-headers": "content-type, x-admin-password",
  "access-control-allow-methods": "GET, POST, OPTIONS"
};

const json = (statusCode, body) => ({
  statusCode, headers, body: JSON.stringify(body)
});
const clean = (value, max) => String(value ?? "").trim().slice(0, max);
const adminOK = (event) => {
  const expected = process.env.ADMIN_PASSWORD || "";
  const supplied = event.headers?.["x-admin-password"] || "";
  if (!expected || !supplied) return false;
  const a = Buffer.from(expected);
  const b = Buffer.from(supplied);
  return a.length === b.length && timingSafeEqual(a, b);
};

export default async (event) => {
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers };
  const path = event.path || "";

  try {
    if (event.httpMethod === "POST" && path.endsWith("/submit")) {
      const data = JSON.parse(event.body || "{}");
      const message = clean(data.message, 500);
      const nickname = clean(data.nickname, 24);
      const kind = data.kind === "secret" ? "secret" : "question";
      if (message.length < 2) return json(400, { error: "내용을 두 글자 이상 적어 주세요." });
      if (data.nicknameMode === "nickname" && !nickname)
        return json(400, { error: "닉네임을 적어 주세요." });

      const id = randomUUID();
      const accessCode = randomUUID().replaceAll("-", "").slice(0, 10).toUpperCase();
      const item = {
        id, accessCode, kind,
        nickname: data.nicknameMode === "nickname" ? nickname : "익명",
        message, createdAt: new Date().toISOString(),
        status: "new", reply: "", replyVisibility: "private",
        rejectedAt: null
      };
      await store.setJSON(`item:${id}`, item);
      const ids = (await store.get("ids", { type: "json" })) || [];
      ids.unshift(id);
      await store.setJSON("ids", ids.slice(0, 1000));
      return json(200, { ok: true, accessCode });
    }

    if (event.httpMethod === "POST" && path.endsWith("/check")) {
      const { accessCode } = JSON.parse(event.body || "{}");
      const code = clean(accessCode, 20).toUpperCase();
      const ids = (await store.get("ids", { type: "json" })) || [];
      for (const id of ids) {
        const item = await store.get(`item:${id}`, { type: "json" });
        if (item?.accessCode === code) {
          return json(200, {
            found: true, status: item.status,
            reply: item.replyVisibility === "private" ? item.reply : (item.reply || ""),
            visibility: item.replyVisibility
          });
        }
      }
      return json(404, { error: "쪽지 코드를 찾을 수 없어요." });
    }

    if (event.httpMethod === "GET" && path.endsWith("/admin")) {
      if (!adminOK(event)) return json(401, { error: "관리자 비밀번호를 확인해 주세요." });
      const ids = (await store.get("ids", { type: "json" })) || [];
      const items = [];
      for (const id of ids) {
        const item = await store.get(`item:${id}`, { type: "json" });
        if (item) items.push(item);
      }
      return json(200, { items });
    }

    if (event.httpMethod === "POST" && path.endsWith("/manage")) {
      if (!adminOK(event)) return json(401, { error: "관리자 비밀번호를 확인해 주세요." });
      const data = JSON.parse(event.body || "{}");
      const item = await store.get(`item:${clean(data.id, 80)}`, { type: "json" });
      if (!item) return json(404, { error: "질문을 찾을 수 없어요." });

      if (data.action === "reply") {
        const reply = clean(data.reply, 500);
        if (reply.length < 1) return json(400, { error: "답변을 적어 주세요." });
        item.reply = reply;
        item.replyVisibility = data.visibility === "public" ? "public" : "private";
        item.status = "answered";
        item.rejectedAt = null;
      } else if (data.action === "reject") {
        item.status = "rejected";
        item.rejectedAt = new Date().toISOString();
        item.reply = "";
      } else if (data.action === "restore") {
        item.status = "new";
        item.rejectedAt = null;
      } else {
        return json(400, { error: "알 수 없는 요청이에요." });
      }
      await store.setJSON(`item:${item.id}`, item);
      return json(200, { ok: true });
    }

    return json(404, { error: "요청을 찾을 수 없어요." });
  } catch {
    return json(500, { error: "잠시 후 다시 시도해 주세요." });
  }
};
