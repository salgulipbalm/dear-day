const API = "/.netlify/functions/api";
const $ = (id) => document.getElementById(id);
let adminPassword = "";

async function request(path, options={}) {
  const response = await fetch(`${API}/${path}`, {
    ...options,
    headers: {
      "content-type":"application/json",
      ...(adminPassword ? {"x-admin-password":adminPassword} : {}),
      ...(options.headers || {})
    }
  });
  const data = await response.json().catch(()=>({error:"응답을 읽을 수 없어요."}));
  if (!response.ok) throw new Error(data.error || "요청을 처리하지 못했어요.");
  return data;
}

document.querySelectorAll(".tab").forEach(btn => btn.addEventListener("click", () => {
  document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b===btn));
  document.querySelectorAll(".panel").forEach(p=>p.hidden=p.id!==btn.dataset.tab);
}));

document.querySelectorAll('input[name="nicknameMode"]').forEach(r => r.addEventListener("change", () => {
  $("nickname").hidden = document.querySelector('input[name="nicknameMode"]:checked').value !== "nickname";
}));

$("sendForm").addEventListener("submit", async e => {
  e.preventDefault(); $("sendResult").textContent="쪽지를 보내고 있어요…";
  try {
    const data = await request("submit",{method:"POST",body:JSON.stringify({
      kind:document.querySelector('input[name="kind"]:checked').value,
      nicknameMode:document.querySelector('input[name="nicknameMode"]:checked').value,
      nickname:$("nickname").value, message:$("message").value
    })});
    $("sendResult").innerHTML = `쪽지를 잘 보냈어요! 답장을 확인할 수 있도록 이 코드를 꼭 저장해 주세요.<br><span class="code">${data.accessCode}</span><br>이 코드는 다른 사람에게 보여 주지 마세요.`;
    $("sendForm").reset(); $("nickname").hidden=true;
  } catch(err){$("sendResult").textContent=err.message;}
});

$("checkForm").addEventListener("submit", async e => {
  e.preventDefault(); $("checkResult").textContent="답장을 찾고 있어요…";
  try {
    const data=await request("check",{method:"POST",body:JSON.stringify({accessCode:$("accessCode").value})});
    if(data.status==="answered") $("checkResult").innerHTML=`<b>답장이 도착했어요.</b><br>${escapeHTML(data.reply).replace(/\n/g,"<br>")}`;
    else if(data.status==="rejected") $("checkResult").textContent="이 쪽지는 답변하지 않기로 했어요.";
    else $("checkResult").textContent="아직 답장이 오지 않았어요. 조금만 기다려 주세요.";
  } catch(err){$("checkResult").textContent=err.message;}
});

$("loginForm").addEventListener("submit", async e => {
  e.preventDefault(); adminPassword=$("password").value;
  try { await loadInbox(); $("adminArea").hidden=false; $("loginForm").hidden=true; $("adminResult").textContent=""; }
  catch(err){adminPassword="";$("adminResult").textContent=err.message;}
});
$("logout").addEventListener("click",()=>{adminPassword="";$("adminArea").hidden=true;$("loginForm").hidden=false;$("password").value="";$("inbox").innerHTML="";});

async function loadInbox(){
  const data=await request("admin");
  const items=data.items||[];
  $("counts").textContent=`전체 ${items.length}개 · 새 질문 ${items.filter(x=>x.status==="new").length}개`;
  $("inbox").innerHTML=items.map(item=>`
    <article class="note-card" data-id="${item.id}">
      <div class="note-meta"><span>${item.kind==="secret"?"비밀쪽지":"오늘의 질문"} · ${escapeHTML(item.nickname)}</span><span>${new Date(item.createdAt).toLocaleString("ko-KR")}</span></div>
      <div class="note-text">${escapeHTML(item.message)}</div>
      <div class="status">상태: ${item.status==="new"?"답변 대기":item.status==="answered"?"답변 완료":"거절됨"}</div>
      ${item.status==="answered"?`<p class="note-text"><b>내 답변:</b><br>${escapeHTML(item.reply)}</p>`:""}
      <textarea class="replyText" rows="3" maxlength="500" placeholder="답장을 적어 주세요.">${item.status==="answered"?escapeHTML(item.reply):""}</textarea>
      <label>답장 공개 범위</label>
      <div class="choice"><label><input type="radio" name="vis-${item.id}" value="private" checked> 쪽지 코드로만 확인</label><label><input type="radio" name="vis-${item.id}" value="public"> 공개 기록에 표시</label></div>
      <div class="actions">
        <button data-action="reply">답장 보내기</button>
        ${item.status==="rejected"?'<button data-action="restore">다시 받기</button>':'<button class="danger" data-action="reject">거절하기</button>'}
      </div>
    </article>`).join("") || "<p class='hint'>아직 도착한 쪽지가 없어요.</p>";
  $("inbox").querySelectorAll("article").forEach(card=>card.querySelectorAll("button").forEach(btn=>btn.addEventListener("click",()=>manage(card,btn.dataset.action))));
}
async function manage(card,action){
  const id=card.dataset.id;
  try{
    const body={id,action};
    if(action==="reply"){
      body.reply=card.querySelector(".replyText").value;
      body.visibility=card.querySelector(`input[name="vis-${id}"]:checked`).value;
    }
    await request("manage",{method:"POST",body:JSON.stringify(body)});
    await loadInbox();
  }catch(err){$("adminResult").textContent=err.message;}
}
function escapeHTML(value){
  return String(value??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
